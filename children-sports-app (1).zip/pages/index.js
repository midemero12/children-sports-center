import React from "react";
import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";

export default function Home() {
  return (
    <main className="p-4 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-center mb-6">
        Children Sports Center
      </h1>
      <div className="tabs">
        <div className="tab-list">
          <button>Overview</button>
          <button>Rentals</button>
          <button>Tokens</button>
        </div>
        <div className="tab-content">
          <Card>
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold mb-2">Our Business</h2>
              <p>
                We sell, rent, and distribute pool tables and related equipment
                across Nigeria. Our target customers are bars, clubs, lounges,
                restaurants, and other indoor entertainment venues.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}