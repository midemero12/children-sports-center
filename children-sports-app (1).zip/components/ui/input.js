export function Input(props) {
  return <input {...props} style={{ padding: "8px", borderRadius: 4, border: "1px solid #ccc" }} />;
}