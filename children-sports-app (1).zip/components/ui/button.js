export function Button({ children }) {
  return <button style={{ padding: "8px 16px", backgroundColor: "#0070f3", color: "#fff", border: "none", borderRadius: 4 }}>{children}</button>;
}